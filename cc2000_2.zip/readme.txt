############################################################################################
# CAMPAIGN CREATIONS 2000                                                                  #
#                                                                                          #
# Map Design by DI [12.31.99]                                                              #
#                                                                                          #
# Special thanks to Joel, Desler, Ravage!, Meth and everyone else at Campaign Creations.   #
############################################################################################

INSTALLATION:

1) Make sure you have downloaded both cc2000_1.zip and cc2000_2.zip, or the equivalent
   archives which contain both:

   cc2000.scx
   cc2000.exe

   (or the Macintosh equivalent)

2) Unzip cc2000.scx into your Starcraft/maps/ directory. Unzip cc2000.exe into a location
   where you can access it.

3) Run cc2000.exe by double clicking on it. Select Starcraft. Start a Single Player 
   Broodwar game and select Custom Scenario. Browse your maps/ directory until you find 
   cc2000.scx and start the game.


NOTES:

- Requries 'Starcraft: Broodwar' version 1.05 or later to play.

- Turn off the default Starcraft music before the mission begins; there will be in-map
  replacements. You will be prompted before the actual mission begins.

- The level must be played at the "fast" game speed for events to be synchronized
  correctly. This is the default, so just don't change it. (May lag on slower machines;
  e.g., sub-200 pentiums, but the level will still work out)

- Pausing the game or accessing the menu will cause events to desynchronize also. You will
  not have to worry about those issues anyway; just watch.


LINK:

http://www.campaigcreations.com

############################################################################################

Have Fun!

- DI