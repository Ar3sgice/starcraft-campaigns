   The Bob Bonus Levels
   Bonus 1 - Clone Wars 1.1

  The Bob Bonus Levels have no connection to the regular Bob Levels
other than the fact that I made them, and Bob is in them.

  Bonus Level 1 is based on the concept of The Bob Levels 1:
Chapter 2: "And then a hero comes along" in which you train Zerg
heros to fight against Terran heroes. I've extended the idea, so
that you can now fight against all three race's heroes, and you
can pick which race you want to use yourself.

 Tassadar and Zeratul do not have archon warp as one of their
abilities. To make either an Archon or Dark Archon, bring 2 Tassadars
or two Zeratuls to the beacon by your base.
  To morph a Hunter Killer into a Heroic Lurker, send it to the beacon
as well. This will cost 50 Minerals and 100 Vespene.

  THIS IS NOT BALANCED! At least not well. Blizzard didn't make the
heros so they would balance out. The only change I've made is lowering
Fenix (Zealot)'s stats, since I found that otherwise the Protoss would
rush a bunch of *really strong* Zealots that I couldn't stop.

  I have been able to beat this with Zerg (using Lurkers) and Terrans
(without BW units), and Protoss (using Dark Templar). I don't play on
Battle.net (my internet connection tends not to last long), so this
was the first time I've ever had to use rushing as a strategy (Custom
AIs are much tougher than any of the campaign AIs). I've found that
I can generally knock out 2 of my enemies right away, but the third is
always trickier, so I advise making sure that the third is a race with
some weakness in regards to your whatever race you are (in my case,
this is usually the Terrans with their detection weakness).

  This campaign works by replacing the removing a unit you've trained
and replacing it with the hero. Because of this, you may notice that
if you select a unit right after it's been trained, you will lose the
selection. Just reselect the newly placed hero. Also, the trigger
sometimes takes a few seconds to take effect, and if you train mass
quantities at once (such as 3 Zerg Larvae to 6 Zerglings) it may take
several seconds to convert the unit into a hero. I apologize, but
there's nothing I can do to speed it.

  Unfortunately, the computer cannot be told to treat heroes like
normal units, so there are a few things you should be aware of (having
said so, I now pull out a huge list).

  -The computer's units are actually normal units with the same
   stats as their hero equivelants. With a few exceptions, this
   shouldn't affect anything besides their portraits.
  -The computer's High Templar will be unable to use Psi Assault,
   the normal attack of Tassadar (you can use it).
  -Your Infested Terrans will become Infested Kerrigan. the computer's
   Infested Terrans will be normal infesteds with 200 HP.
  -BW ONLY: Blizzard didn't make any heros for the new units. I have
   upped BW units stats and added "Heroic" to their names (I wasn't
   feeling creative enough to give them names).
  -Kerrigan (ghost) cannot nuke. I have removed the nuke silo.
   (otherwise, the computer would still be able to nuke you).
  -In the scm, the scout hero is Mojo. For BW, it is Artanis (Mojo
   has more HP).
  -Your mutalisks are not the hero unit, but their stats are the same.
   This allows them to morph into Guardians and Devourers.
  -Heroes do not take up supplies/control/psi. This works to your
   advantage, since you usually have the real heroes.
  -The Overlord hero provides 30 control. The computer's Overlords
   still provide only 8 control.
  -Terrans have 2 Battlecruiser heroes, Hyperion and Norad II. You
   get the Norad II (it may have crashed, but it has a good deal more
   firepower than the Hyperion).
  -The following units have no heros, and so have remained the same:
   SCV, Drone, Probe, Observer, Scourge, Shuttle, Dropship.
  -Version 1.1 - Lowered Fenix (Zealot)'s Shield to 200, HP to 150,
   and attack to 34 in an effort to balance the game somewhat.

  If you have found any trigger bugs on *any* of The Bob Levels, please
email me at tj9582@zerg.com and tell me. I have tested these levels
thoroughly and think I've worked out all the bugs, but it can be hard
to plan for every possibility (this level was actually easy to test;
I'm almost positive there are no bugs). Feel free to also email any
comments, questions, or ideas for future Bob Levels.

  Download The Bob Levels CWAD to enhance the Bob experience. StarDraft
is required.

  The Bob Bonus Levels
  http://www.geocities.com/Area51/Dimension/7763/BobBonus.htm

  Created by Tim <tj9582@zerg.com>