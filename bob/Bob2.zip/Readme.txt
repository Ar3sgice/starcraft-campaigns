
                    The Bob Levels II (Enhanced!)


     INTRO, or
      How I Learned to Stop Worrying and Love the Campaign Editor

  Nearly one year has passed since I released The Bob Levels I (Enhanced!),
and promised to begin enhancements on The Bob Levels II. Somewhere between
then and now, real life hit hard, and I went away to college where I was
deluged with work completely unrelated to StarCraft. Bob got put on the
backburner, updates on the site grew fewer and fewer, and by all outward
appearances, The Bob Levels were dead.
  Dead, but not quite forgotten. Every so often, I would see mention of my
campaigns on the various forums, and receive emails from fans. Still, I just
didn't have time to do anything about it. Thoughts of Bob faded from my mind,
and were replaced by homework and EverQuest.
  But then everything changed. It was about a month until the end of the
school year, and I was sitting in the monkey cage, my punishment for the
perpetration of what would come to be known as "The Spoon Incident." It was
late at night, and I was just drifting off to sleep when I heard a strange
scratching sound. Rousing slowly from my slumber, I saw to my surprise that
one of the monkeys was picking the lock to the cage. Soon the door was open,
and the monkeys leapt out, darting with ease from rock to rock over the moat
that surrounded the enclosure, and into the hallways of my school. Curious,
I followed them (rumor has it that the moat is stocked with crocodiles, but
this is entirely untrue. It has alligators, which, as everyone knows, are not
nearly as aggressive as crocodiles). I soon tracked their dirty footprints and
jungles cries to the main computer lab. Peeking in the door, I was shocked to
see them all pounding furiously away at the keyboards (with the exception of
Matt. We had just lobotomized him in Psychology class, so he just sort of sat
there and stared at the screen clueless. He would have fit in well with the
civil engineers).
  There were monkeys hacking into the Pentagon, monkeys writing emails to their
friends at neighboring colleges, monkeys discussing weighty issues in chat rooms
(this explains a lot, I think), and even one monkey in the far corner who seemed
to be randomly pounding the keyboard, but upon closer inspection could be seen to
be reproducing the works of William Shakespeare (this was rather strange, as we
are a technical school, and have no humanities students). But the monkey that
really caught my attention was sitting in the middle of the room, playing StarCraft.
  More than that, he was playing The Bob Levels. My levels.
  His piercing laughter soon caught the attention of the other primates, who
gathered around him to watch. Soon, they too were entranced. "Ook ook ok!" said
one of the smaller ones (roughly translated, this means "Funny! Me play!"). The gamer
quickly snapped back "Ek ek oo ah ah ek!" ("I will throw my doodoo at you if you don't
shut up!") Fortunately for the other monkeys, the CD burner was online, and soon they
were all playing along.
  I feel that I should take this moment to point out that pirating is very bad, and
by no means should you do it. This is the same as stealing, and I'm sure you don't
want to steal. Because if you do steal, the cops will eventually track you down and
lock you up, and then you will go to prison, and even if you get out early, nobody will
hire you because of your criminal record, and you will become a homeless bum who will
die of hypothermia, a bitter, unmissed, unwept man (or woman). (I am joking, of course.
Women don't play video games, and so they would never pirate StarCraft).
  Monkey morality, however, is rather lacking, and they played those Bob Levels to their
little homonid hearts' content, never noticing me.
  At least, they didn't notice me until I made a mistake that I am still rather ashamed
to mention.
  I laughed at my own joke.
  I couldn't help it! The mood of the monkeys was catchy, and I had actually forgotten
some of the punch lines that I had written so long ago. So I laughed. The room went silent,
and all heads turned to me. Several simians scooped up their poop, ready to throw it at
me if I made a false move.
  "The boy knows too much. He must be eliminated," said the elder monkey (which, roughly
translated, is, "ook, eek ee ee EE!")
  I knew what they were going to do. They would throw me into the chemistry supply room.
Nobody ever comes back from the supply room. I was doomed. But, mischievous things that
they are, one of them decided to steal my wallet first, and noticed my student id card.
  "It's TIM!" he screamed. The next thing I knew, they were bowing to me, chanting, and
piling offerings of excrement at my feet.
  It was at that moment that I realized that The Bob Levels were far more than a humorous
campaign. They were my ticket to world domination.
  I knew that I had to continue work on them.
  And so, here is the long delayed Enhanced! version of Bob II.
  May it bring joy to your monkey.


     CHANGES, or
      The Next Step in Campaign Evolution

  The following changes and/or additions have been made in this Enhanced! version:
-Move maps. Completely new to the Enhanced version, there is an intro movie and an ending
 movie. Not yet available on DvD.
-Bug fixes. Once again, Mr. Lemmer has tracked down batches of bugs, and once again I have
 cleaned them out. If anything was missed, blame Mike.
-Now contains 52% more coolness!
-New dialogue. Since, as we all know, StarCraft is about talking out our problems instead
 of resorting to violence, I have tried to capture this spirit by having everyone talk more.
-Prettier dialogue. Text is now colored and formatted for your reading pleasure.
-Gratuitous violence. Technically, this is not new, but it sure is fun!
-Ian the Interceptor. Ian first started doing after-briefing shows in the unenhanced version
 of Bob II. However, all he really did was say "Hi" and "Bye." He has cooked up a fresh new
 batch of after-briefing specials for you.
-The Old Guy appears in every map (including the cinematics).
-A entirely new feature has been added to this edition: the Pointless Bonus Scene. By doing
 some random, useless thing in each level, you will be rewarded with a very short, very stupid
 cut scene. Unlock them, watch them, and then wonder why you bothered!
-More noise. Using the "sounds w/o size" trick, there are now voices to accompany the text.
-Misc. tweaks to triggers and maps for smoother and more enjoyable Bobness.


     CREDITS, or
      In Which I Blame Others For This Campaign

Level Design, Trigger Work, Story, etc:
  Tim

Bug Patrol, Suggester of Ideas:
  Mike Lemmer

Guy Who Threw a Brick Through My Window With a Note Saying to Put Him in the Credits:
  Slick_Gecko

Creators of StarCraft and BroodWar:
  Blizzard

Creator of the Light Bulb:
  Thomas Edison

Creator of the Universe:
  God (or, if you find that offensive, not God)

Scary Neighbor Who Sometimes Passes Out Naked On His Front Lawn:
  Joe Mauer


     LINKS, or 
      More Ways to Waste Time

If you have the strange desire to contact me, write to 
 tj9582@zerg.com

For all Bob-related items go to
 www.starcraftsilo.com/starcraft/bob

For darn good StarCraft humor, check out
 www.starcraftsilo.com/scantidstudios

For a good deal on a great car, visit
 your local Honda dealer today!