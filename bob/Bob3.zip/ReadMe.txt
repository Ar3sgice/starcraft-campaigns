                               The Bob Levels III
                                      ReadMe

  Read this carefully! There will be a quiz at the end.
  If you've played the previous Bob Levels, then you should have no problem understanding what 
is going on. If you haven't, you still shouldn't have much trouble. These are The Bob Levels, 
after all. They're not too heavy on plot. Nonetheless, to help you out, I have included a not-
so brief summary of the previous Bob Levels.


                               Not So Brief Summary

  Just before the death of the Overmind, three new cerebrates were born on Aiur. Bob the Cool 
Cerebrate planned to use his brood to have fun, and maybe become a hero while he was at it. 
Janet the Evil Cerebrate wanted to kill everyone and take over the universe. Joe the Dumb 
Cerebrate wanted to sit around on Aiur. Bob and Janet fought and Bob killed Janet then left 
Aiur.
  Bob soon discovered that Janet had been part of a great evil conspiracy called the Bad Guys 
Alliance and led by Aaron the Devious Terran. He attacked a space platform where they were 
cloning heros, and freed Jim Raynor, Bill Nye the Science Guy, and a civilian in the process. 
He then found and freed Fenix, who told of the Bad Guys' attack on the Dark Templar homeworld. 
Bob went to help out Zeratul, killed Edmund Duke in the process (I never liked Duke much), and 
finally attacked The Bad Guys Alliance's home planet. He eventually destroyed the entire base, 
at which point the aforementioned civilian got all upset and revealed that he was in fact 
Aaron, that he had formed the Bad Guys Alliance to get back at all the people who made fun of 
him for being a worthless civilian, and then teleported away. Bob and his newfound allies 
formed the Good Guys Alliance, Bob settled on the planet that he had taken from the Bad Guys, 
and everyone was happy.
  Then Brood War happened.
  Fortunately, it did not affect Bob at all, except for providing him with new units and some 
nice new triggers. Oddly, Duke appeared in Brood War and was killed, despite having already 
been killed in The Bob Levels I. Blizzard has yet to explain the discrepancy between Brood War 
and previous events in The Bob Levels.
  Aaron rebuilt the Bad Guys Alliance, and set out to find the Uraj and Khalis crystals, since 
the Protoss had demonstrated that if you posses both crystals, all of your enemies die. He 
succeeded in acquiring one crystal, but Bob beat him to the other. Aaron then attacked Bob 
viciously, and Zeratul fled with the crystal to a nearby warp gate. Along the way, he met 
Jake/Larry, an archon composed of two High Templar who hated each other. Jake/Larry helped 
Zeratul reach the warp gate, but just as they were about to go through it, it exploded and 
Aaron appeared demanding that they hand over the crystal. Suddenly, a large number of critters 
attacked both the Good and Bad Guys while 3 Kakarus whisked Zeratul, Jake/Larry, and Aaron 
away, along with their crystals.
  It was soon discovered that the critters, sick of being clicked to death and otherwise killed 
by warring people, had joined together and become militant. Led by Ursula the Rynadon and Ryan 
the Ursadon, they planned to use the crystals to wipe out all non-critters, and thus be safe 
once again. The Critters had also acquired a giant Psi Emitter which they used to control their 
own batch of Zerg. The Good Guys were forced to work with Aaron and escaped the Critters' 
planet, Aaron with the Khalis, and the Good Guys with the Uraj. A final showdown occurred in 
which the Critters' Psi Emitter was destroyed, freeing their Zerg, and the Bad guys were once 
again soundly defeated. Aaron once again popped up and complained about being defeated, and 
Jake/Larry ran up to him and tried to grab the Khalis from him. In the process, Jake/Larry 
dropped the Khalis and it shattered. Aaron then used the typical bad guy line of "I'll be back" 
and teleported away.
  And then Bob III happened. You'll have to play it to find out the saga's conclusion.


                                  Level Issues

  Unlike its 5 campaign predecessors, The Bob Levels III has 7 levels, which is why it took 
forever to finish (that last level was a killer). In addition, you work for all three sides 
(Good Guys, Bad Guys, and Critters) over the course of the campaign.
  You may have some questions related to a few of the levels, particularly the last one. Here I 
address anything I think the player might find unclear.

 Level 1 - Return of the Bad Guy - Bad Guys
  -If you're confused by this level, you are an idiot. Bring Jack to the Mega-Blaster and kill 
the SCV rebels. Simple.
  -There is a secret. Can you find it?

 Level 2 - Don't Feed the Animals - Critters
  -Don't know where to go take your critter? How could I make it any more obvious? Look at the 
area that has been conveniently revealed on the map for you.

 Level 3 - To Moon a Cerebrate - Bad Guys
  -Swift executions reduce infighting greatly.

 Level 4 - The Fall Of Bobby's World - Good Guys
  -Those ships that fly across the field then blow up are crashing, okay? That was the best I 
could do, and it took me a while, so you better like it!

 Level 5 - What Goes Up, Must Come Down - Critters
  -Using Warrior critters is easy. You walk them over to an enemy unit, the enemy unit dies. 
Very nice. They can't destroy buildings, because that would be too easy.
  -Watch your air forces carefully. Every five minutes, all of your air units over high ground 
die.

 Level 6 - No Pickles - Good Guys
  -This level contains no pickles. I am very sorry for this, but it was due to factors beyond 
my control. We apologize for any inconvenience this may have caused.
  -DO NOT USE "power overwhelming" ON THIS LEVEL!!! The level will not work right, and may 
never end. Certain triggers depend on the computer players being able to kill each other. So 
there, you cheater.

 Level 7 - The Final Battle - User Selectable!
  -This level is unique in that you choose who you want to help win. Go to the beacon of your 
favored side, or go through them all. Each course is different.
  -There are several "modes" in this trigger-heavy baby.
  -Logic Puzzle - There are only two and they're very simple. Figure them out.
  -Cowboy Mode - Fire at your target to heard him toward the destination. If you're corralling 
Aaron and he gets stuck in some crevice or just starts walking back and forth for inexplicable 
reasons, go to the Restart Beacon. Aaron will start to walk back to the beginning, but you can 
still intercept him. If you're herding an air unit, make sure it doesn't get stuck on the edge 
of the screen.
  -Survival Mode - You will be given a building and several invincible units to defend it with. 
Enemy units will attack you. Kill them.
  -Assault Mode - You will be given several buildings and a set amount of resources with which 
to choose and upgrade your army, then use them to destroy an enemy building. (Note: The units 
you trained will be removed once (if) you succeed. Upgrades remain with you.)
  -There is a secret. I'm not telling it to you. I've already said too much.


                                    FAQ

  Here, I answer any questions you might have, as well as several that you may not.
 
 WHO THE HADES IS THIS OLD GUY?
  He follows you around and hides somewhere on each level. Go up to him and he'll say a bit 
then stop. He's mostly harmless, and there for amusement, and to give you something to find.

 WHAT INSPIRED YOU TO DEPART FROM THE TRIED AND TRUE STYLE OF THE BOB LEVELS?
  I felt that it was time to strike out and expand my artistic horizons through greater 
personal expression.
  Actually, I just felt like it. I was getting tired of the Aaron-attacks-Bob,Bob-beats-Aaron 
formula. Also I realized that I was missing an essential part of StarCraft, namely, the fact 
that you work for every side, being such a turncoat that you make Duran look trustworthy. 
Besides, everyone thought it was cool that you could make someone besides the Good Guys win.

 ISN'T LETTING THE USER CHOOSE THE ENDING JUST A COP-OUT TO KEEP YOURSELF FROM HAVING TO COMMIT 
TO ONE?
  Yes. Although I am quite happy with one of the endings, and will almost certainly use it in 
the unlikely event I make more levels. (No more campaigns. I have been toying with the idea of 
an RPG, but if I do, its a long way off).

 WHY AM I YELLING ALL MY QUESTIONS?
  It makes it easier to distinguish the question from the answer, thus allowing the reader to 
skip to the question of their choice.

 OH. THAT MAKES SENSE.
  Yes, it does.

 WHAT MAKES THE BOB LEVELS DIFFERENT FROM THE MILLIONS OF OTHER CAMPAIGNS OUT THERE?
  They're spoofs. They're meant to be humorous, not serious. How many campaigns have you seen 
that even use the word "cool"? Or name a cerebrate Bob? That's what I thought. Also, I have 
given consideration to those with slow modems (like myself) and have kept everything under 1 
Meg! You will rarely find 7 levels in less than a Megabyte.

 I HATE YOU. TO WHAT EMAIL ADDRESS SHOULD I SEND MY DEATH THREAT?
  Send all death threats, questions, or comments to tj9582@zerg.com.

 WHAT ABOUT BUG REPORTS?
  If you *gasp* find a trigger bug in these levels, please email me immediately and I will fix
it as soon as possible. I just know that last level is crawling with them, even I've tested 
every single one over and over again.

 I WANT TO SPREAD THE GOSPEL OF BOB. ARE THERE ANY RULES ON THE REDISTRIBUTION OF THESE LEVELS?
  You are free to submit them where ever you want, as long as they are unchanged. You may 
change whatever you want in your personal copies, as long as you don't spread such tainted 
filth! I have left the maps unlocked since I myself like to look at other's triggers. Be aware, 
however, that I used the Emerald Aspect Patch for this, and so if you open it without that, 
StarEdit will complain about weird units and probably won't show the special ai scripts 
properly. Also, I did a small amount of hex editing to change the player colors on most of the 
levels, which will get lost when you save in StarEdit.


                                         Quiz

  I told you there would be a quiz at the end. You should have listened. Please answer the 
following questions.

1. What is your name?
2. How many levels are in this campaign?
3. What is the average velocity of an unladen sparrow?



Answers:
1. Tipper Gore
2. 7
3. Depends on if it's an African or a European sparrow.

 If you got any of these wrong, it is your obligation to the human race to jump off a bridge
and remove yourself from the gene pool.


                                         Links

  The Bob Levels I
 (For the original Starcraft)
http://www.geocities.com/Area51/Dimension/7763/BobLevels.htm

  The Bob Levels II
 (For Brood War. Much better than The Bob Levels I)
http://www.geocities.com/Area51/Dimension/7763/BobBrood.htm

  The Bob Levels III
 (For Brood War. You already downloaded them, or you wouldn't have this Readme.)
http://www.geocities.com/Area51/Dimension/7763/BobThree.htm

  The Bob Bonus Levels
 (Not necessarily related to The Bob Levels. Efforts are taken to maintain compatibility
 with the original StarCraft, but some require BW. The Cow Level can be found here.)
http://www.geocities.com/Area51/Dimension/7763/BobBonus.htm

  The Bob Levels CWAD
 (Makes several aesthetic changes to make StarCraft more Bob-like. I may update it sometime
 in the future. BW and StarDraft required.)
http://www.geocities.com/Area51/Dimension/7763/Bob2Cwad.zip

     -Tim <tj9582@zerg.com>