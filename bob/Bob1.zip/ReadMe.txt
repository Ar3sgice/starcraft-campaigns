                             The Bob Levels I (Enhanced)


  This is where it started. The long saga that is Bob's began with this series of five
humble campaigns. From them have grown many more levels, and even a small following of
crazed fans. But how did it all begin?
  It's quite simple, really. The Bob Levels were a mistake. That's right. They were never
meant to be. I made level 2 and 4 all on their own because I wanted to train dark templar
and heroes. Then, inexplicably, a cerebrate named Bob was mixed into them and a few extra
levels were added to glue everything together. I don't even know where the idea of Bob came 
from. My brother claims he originated it, but I think this is akin to Al Gore claimed credit 
for the internet.
  So now you know the truth. I never meant to make The Bob Levels. They just sort of came
into being. Was it fate? Or just the product of a raving mind?
  Do you even care?
  Probably not. You just opened this file because tradition dictates that you open the
readme.txt right away. So I'll get down to the relevant information.

Things that I have changed (and there are many):
 - Prettier text. It is an established fact that the thing people most want from a campaign
   is pretty text. Ever the crowd pleaser, I have made all text nicely formatted and colored.
 - New dialogue. Most of it is inane, but it's still dialogue. More talking will occur during
   and at the completion of missions. Mission briefings have been fixed up, and the first one
   was totally redone.
 - Ian the Interceptor. Everyone's favorite after-briefing speaker is back in full force.
   Don't be too fast to click the 'Start' button.
 - The Old Guy. This mysterious figure from Bob 3 hides somewhere on each map. If you can
   find him, you get to hear him drone on about the old days and insult you! What a reward!
 - Bug fixes. Believe it or not, there were bugs. Of course, I don't make mistakes, so they
   were all put there intentionally to see if you were paying attention. However, I have 
   removed them for this version.
 - Cut scenes. A few of these have been added in to enhance the Bob experience. Or something
   like that.
 - A coupon for 50% off your purchase of the sequels. That's right! Bob II & III will cost
   half as much when you present this readme file.
 - Better trigger work. A lot of this won't be noticeable, but the levels will run much more
   smoothly, and a few of the problems that plagued the original version have been remedied 
   with those wonderful new triggers Blizzard provided.
 - Terrain tweaks. Mostly, these involve small reduction in the number of minerals at your 
   base. Don't worry, they still have the insanely large number of minerals I used to provide. 
   I have been very careful to leave the basic gameplay intact, so the changes will be 
   noticeable only to the most observant player with the most free time.
 - There is one exception to the above "gameplay intact" rule, and that is level 5.
   Originally, you had to destroy every last building. Now, you have to destroy 4. You 
   can thank me later.
 - Sound enhanced dialogue. Using the "sounds w/o size" trick, I have gotten sounds to 
   accompany all snippets of conversation.
 - Smaller download size. I deleted several of the sounds that were played upon defeat, 
   since they wouldn't get used much, and took up a fair amount of room. Being a friend
   of the low-bandwidth, the entire campaign takes up less than 1/2 a Meg. You aren't going
   to find that anywhere else, I can assure you.
 - SC compatibility. These maps will work even if you don't have Brood War. You do need the
   1.04 patch, but who doesn't have that? I have not disabled BW units, so if you want to
   cheat with them, go ahead (your friend will call you a big sissy). The only exception to
   this is the final level. No Dark Archons allowed!
 - Other stuff that I can't remember.

  Help The Bob Levels spread over the net like creep over fertile ground (very fast creep).
If you wish to post any of my campaigns anywhere, go right ahead, as long as they remain
unchanged (it would also be nice if you sent me a little email saying so). You can change 
your personal copy all that you want; I truly don't care. However, if you dare to claim these
campaigns as your own creation, I will hunt you down and haunt your every miserable moment.
You could no more evade my wrath than you could your own shadow. I mean it! I know where you
live!
  If you find a bug, place your hand over your eyes and say "I saw nothing. I saw nothing."
  Or, email me and tell me about it. Your choice.
  In conclusion, I would like to thank Mike Lemmer, who identified nearly all of the bugs that
were fixed for this new edition. His input was indispensible. If you so happen to find a bug,
blame him for missing it.


  -Tim <tj9582@zerg.com>
  
  For all your Bob needs, go to:
  http://www.geocities.com/tj9582








































Scroll back up. There is nothing of interest here.