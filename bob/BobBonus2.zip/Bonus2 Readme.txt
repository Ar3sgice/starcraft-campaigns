  The Bob Bonus Levels
   Bonus 2 - The Race

  The Bob Bonus Levels have no connection to the regular Bob Levels
other than the fact that I made them, and Bob is in them.

  Bonus Level 2 is based on the first half of The Bob Levels II:
Chapter 2: "The Finish Line" in which you must win a race in order to
save the universe. In thsi level, you may now choose from either a
Zergling race (in which case your racer will be Fast Running One) or
a Zealot race (in which you once again race with Gary the Speedy
Protoss). You will have four opponents, and many sports fans trying to
stop you.

  Your racer is faster than all of the others, but if you simply race
ahead, you'll be killed by the mines and various enemies. The trick
is to let your opponents go in front of you and take the damage, then
run ahead at the end.

  Your opponents have infinite replacements. If one racer dies, a new
one will appear where the other bit the dust.

  If you die, you lose.

  Not fair, I know. Deal with it.

  This level does not require Brood War, but it does require that you
have the 1.04 patch, as it uses some of the newer triggers (move unit,
etc).


  If you have found any trigger bugs on *any* of The Bob Levels, please
email me at tj9582@zerg.com and tell me. I have tested these levels
thoroughly and think I've worked out all the bugs, but it can be hard
to plan for every possibility. Feel free to also email any
comments, questions, or ideas for future Bob Levels.

  Download The Bob Levels CWAD to enhance the Bob experience. StarDraft
is required.

  The Bob Bonus Levels
  http://www.geocities.com/Area51/Dimension/7763/BobBonus.htm

  Created by Tim <tj9582@zerg.com>