    The Bob Bonus Levels
   Bonus 3 - The Cow Level

  Unlike the other bonus levels, this one can be considered a 
continuation of the other Bob Levels. Though Bob himself is not in it, 
Jake/Larry is, and the level is similar to a Bob Level in other aspects 
as well. This readme will deals with any questions you may have about 
this level, and as such is in the format of Q&A.


   WHAT WAS THE INSPIRATION FOR THE COW LEVEL?

  As you probably recall, when you skipped through the levels in order 
to see the ending (don't lie, we know that you did) you had to type in 
"there is no cow level".
  This is no longer true. With the aid of StarDraft, StarEdit, and 
various pictures and sounds I have indiscriminately stolen and 
modified, I have created a cow level. There are cows for each race, as 
well as a hero cow.


   HOW DO I PLAY THE COW LEVEL?

  Unzip "BobBonus3 - Cow.scx" into the StarCraft\maps folder. Then 
place the "Cow.cwd" file into your StarDraft folder. You must have the 
latest StarDraft (as of this writing, it is the one for the 1.05 patch) 
to play this level, otherwise it will not be a cow level. You can 
download it at http://camelot.warzone.com/.
  To run the CWAD, run StarDraft, click on "Launch the Patch Loader," 
in the next window double-click on the Starcraft icon, then check the 
box that says "Cow.cwd". Starcraft will then run, and you can simply 
load the level from the custom maps section.


   WHAT IS THE MEANING OF LIFE, THE UNIVERSE, AND EVERYTHING?

  Forty-two.


   WHAT CHANGES DOES THIS CWAD MAKE?

  The Ursadon has been replaced with the Terran Cow, the Benglaas with 
the Protoss Cow, Ragnasaur with Zerg Cow, and Scantid with Dark Templar 
Cow. Both normal Kerrigan and Infested Kerrigan have been bumped to 
make room for two special hero cows. The first is Super Cow, the second 
is a surprise. They all have their own sounds, although they mostly 
consist of various moos. Super Cow has some funny sound clips if you 
annoy him, but that's about it. I was somewhat disappointed, but that 
was all I could find. Everyone also has their own portraits, which I 
made myself (it shows). The graphics are not the best, I know, but I'm 
not a graphics designer, so that's the best I could do. Mostly I just 
stole images and made small changes.


   SHOULD I SAVE OFTEN?

  Yes. On my computer, StarCraft occasionally crashes when I'm running
a patched copy. I have not been able to trace it to any specific 
event; it seems more or less random. So, I would advise saving often.


   WHO IS JAKE/LARRY?

  He is probably my favorite of all the characters I've made. Jake and 
Larry were once two separate High Templar. They absolutely hate each 
other. During some battle, they were forced to meld with each other 
into an Archon. The result was a hero who spends most of his time 
fighting with himself. He was first introduced The Bob Levels II: 
Chapter 3: "The Twilight Zone", where he crashed on a planetoid and was 
helped off by Zeratul.
  You will notice that sometimes when he talks, it says Jake/Larry, 
and other times it says Larry/Jake. Apparently this confused some 
people. Whoever's name is first is the one doing the talking. Jake is 
generally more serious than Larry, and very big on being a hero. Larry 
just wants to stay alive.
  When the idea of Jake/Larry first occurred to me, I had two possible 
roads to take. I wanted either to make an Archon hero of two enemies, 
or two lovers who decided to meld so they could be together forever (a 
subset of this option would be to have them either always talk about 
how much they loved each other, or have the romance wear off and have 
them fight a lot). I eventually decided that the first option would be 
a whole lot funnier, at which point I gave him a name (The names of 
everyone in the Bob Levels were chosen entirely at random, with the 
exception of Bob, Bill Nye, and those who were already named. I swear 
that I did not choose the name Aaron because it rhymes with Terran.) 
and wrote him into The Bob Levels II. I just wish I'd thought of him 
earlier.


   HOW DO I TAKE THE TOUR OF FARMER LOUIE'S FARM?

  Bring Jake/Larry to Farmer Louie. It won't work with anybody else.


   HOW DO I RESCUE THESE COWS?

  Mind control them with Dark Archons and take them to the beacon by 
Farmer Louie. Unfortunately, you cannot select multiple cows at once. 
Also, I have noticed that for some reason it sometimes takes several 
tries to get them to actually walk onto the beacon. I don't know why. 
Blame Blizzard, not me.


   WHO IS THAT MASKED COW?

  That's Super Cow, defender of bovines everywhere. He is an all-new 
hero exclusive to the Bob Levels. Nobody knows what his true identity 
is, but we can be sure that whenever there's a cow in need, Super Cow 
will don his brightly-colored and very tight outfit and rush in to save 
the day.
  Like any good super hero, Super Cow wears a cape, can fly, and shoots 
laser. He's also a detector, and has both HP regeneration and shields 
(shield batteries do not seem to refill him, sorry). Additionally, he 
can lockdown and cloak, although I'm not sure how useful you'll find 
those.


   YOU DON'T HAVE MUCH OF A LIFE, DO YOU?

  No, not really.


   WHAT ARE THE RULES FOR DISTRIBUTING THE BOB LEVELS?

  You are free to redistribute any of the Bob Levels as long as you 
leave them unchanged. For your personal use, you can make whatever 
changes you want, such as making the AIs easier (wimp) or harder 
(show-off).


   I FOUND A BUG. WHAT DO I DO?

  Step on it. Ha ha.
  If you found a trigger bug on one of my maps, please email me at once 
and describe it to me. I've tested each level thoroughly, and I think 
I've cleared all the bugs out, but I could be mistaken. So far, I have 
not received any complaints, but that could be because nobody's telling 
me.
  Please tell me if you find one. Even the pros always have some bugs 
slip through (as evidenced by the numerous patches Blizzard has
released for StarCraft).
  My email address is tj9582@zerg.com. Feel free to email me with any 
other questions or comments you may have.


   COULD YOU PLEASE ADVERTISE FOR ALL THE OTHER BOB LEVELS?

  Gladly.

  The Bob Levels I
 (For the original Starcraft)
http://www.geocities.com/Area51/Dimension/7763/BobLevels.htm

  The Bob Levels II
 (For Brood War. Much better than The Bob Levels I)
http://www.geocities.com/Area51/Dimension/7763/BobBrood.htm

  The Bob Bonus Levels
 (Not necessarily related to The Bob Levels. Efforts are taken to maintain compatibility with the original StarCraft, but some require BW.)
http://www.geocities.com/Area51/Dimension/7763/BobBonus.htm

  The Bob Levels CWAD
 (Makes several aesthetic changes to make StarCraft more Bob-like. It is recomended that you don't use this CWAD with The Cow Level. It was tailored specifically for The Bob Levels II. BW and StarDraft required.)
http://www.geocities.com/Area51/Dimension/7763/Bob2Cwad.zip

  StarDraft
 (Not affiliated with The Bob Levels in any way, but required to run the CWADs. It is only necessary to run a CWAD for The Cow Level.)
http://camelot.warzone.com/

     -Tim <tj9582@zerg.com>