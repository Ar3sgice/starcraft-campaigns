Legacy of the Confederation
"Episode II: Dawn of Darkness"

Get ready for among the most highly anticipated StarCraft campaign experiences ever released.  You're in for a wild ride, but before you play, let's quickly review some installation instructions so everything will flow smoothly for you.

1)  First step, download the Portrait/Sound pack and "Extract" the folders directly into your Starcraft folder.  This ZIP file contains "2" folders, one called portrait and one called sound.
Once extracted, just leave them there and you're finished with this part.

**Note:  If ever you want to return to using your normal portraits and sounds, just delete the ConFed folders or rename them.

2)  Download at least Mission 1 of Episode II("Strike First, Strike Harder").  You must UNZIP this mission into your Starcraft "MAPS" folder.  ((The path is C:\Program Files\Starcraft\Maps\))  You can make a separate folder for Legacy of the Confederation if  you choose 'ADVISED.'

3)  Download the ConFed startup pack.  Extract this into your starcraft directory.  The file you extracted is called "ConFed.exe"  Just double click it.  On the next screen hit "OK" and on the next screen after that, select the "Starcraft" icon.  Then you are on your way.  Have fun!!!


CREDITS:

Story:  E.S. Clarke
Graphics:  Joel Steudler
Triggers: E.S. Clarke
Mission Design:  E.S. Clarke
Advertising:  DI(JQpanG)/Desler/Campaign Creations
HTML Layout:  DI(JQpanG)
Script:  E.S. Clarke

CAST:

(Stars/CoStars)
"Karla Wainwright" - Gloria Rodriguez-Naranjo
"Mustapha Ra'Chek" - Joel Steudler
"Gerson Drake" - Joe Antholzner
"Mick Furlong" - Ben Richards
"Professor Algernon" - E.S. Clarke
"Vaeregoth" - E.S. Clarke
"Zuhl" - E.S. Clarke
"The Oracle" - E.S. Clarke
"Captain Barreto" - Alexander Naranjo
"Captain Bates" - BiLLiUM
"ConFed Tactical" - E.S. Clarke

(Extras)
"Recreations Master (Chau Sara) - Fawad Haq
"Director Steward (Chau Sara) - Joel Steudler
"Med-Lab Security (Chau Sara) - E.S. Clarke
"Security Chief Jenson (Chau Sara) - E.S. Clarke
"Female Announcer (Chau Sara) - Cindy 'SinFulSoul'
"Scraggs (Arcturus Prime) - Aaron Martinez
"SNN Anchor" - E.S. Clarke
"SNN Hugh Walters" - Brian McPherson
"Borialis Command (Mar Sara) - Craig Rydell
"Prelate Zathren" - E.S. Clarke
"Morian Governor" - E.S. Clarke
"Mr. Longsteen" - Craig Rydell
"Female Computer" - Unknown
"Captain Adnan Raja" - Adnan Raja
"Scared Marine (Delta Crateris IV) - Rashid Haq

(New Units)
"Confederation Battle Platform" - Joel Steudler
"ConFed U-22 Specter" - E.S. Clarke

(Blizzard Personalities)
Arcturus Mengsk
General Duke
Zeratul
Infested Kerrigan
Civilian
Marine
Female Computer

**All blizzard voices are owned by Blizzard Entertainment and used by LotC under the express guideline that no commercial gain results from distribution of this campaign.  LotC staff and crew acknowledge that quotes from the above Blizzard characters are taken out of context from actual blizzard campaigns for use as cameo appearances in LotC.  All rights reserved by Blizzard Entertainment.

