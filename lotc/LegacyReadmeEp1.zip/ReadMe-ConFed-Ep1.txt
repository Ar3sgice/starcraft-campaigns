***Thank you for downloading the Legacy of the Confederation campaign first episode: Past Purposes.  We promise to provide you with a campaign experience unlike any other.  Please read this entire file before proceeding to play the series***

INSTALLATION: (WITH STARDRAFT ENHANCEMENT)

1)  First, take the "Legacy" folder contained in THIS zip file and place it in your "Maps" directory in the starcraft main directory.  The proper path is C:\Program Files\Starcraft\maps\Legacy.  (That assumes "C" is your main hard drive.  If not, put whatever letter corresponds to your primary HD)

2)  Each Mission in the first episode comes in a separate "Zip" file.  You will need to use a utility such as "winzip" or "Pkzip" to 'unzip' the files.  Once unzipped, place the mission (LegacyPrologue.scx for example) in the "Legacy" folder that you placed in your maps folder in step #1.

3)  Once the missions are in your "Maps" folder, look for something in the legacy folder called "ConFed-Episode_1.exe".  Double click on that, and when the ConFed symbol pops up, select "OK" and on the next screen, select the "starcraft" icon, NOT the "staredit" icon.  Starcraft Broodwar will fire up at that point and will be patched to contain the new hero voices from this episode.

4)  Then just go to "single player", select "Play custom" and in the custom screen, find the legacy folder and select "LegacyPrologue.scx" (the first mission of the series.)  

5)  The mission will start at this point, all we can say is hold onto your seats.

6)  ***Note:  If you don't download all of the maps at once, and you "win" the maps you do have, eventually you'll see a message after you win that says "Unable to find specified campaign file."  At that point you'll need to go download the next episode and manually select it on the custom screen.  (If you download all at once, the maps will automatically carry you to the next one, so you won't need to do anything after starting the Prologue)


INSTALLATION: (WITH SOUND FOLDER)

1)  Take the folder "SOUND" and place it in your MAIN Starcraft directory.  The final path should be C:\program files\starcraft\sound\

2)  If you already have a folder named sound, rename it something else temporarily so that the one from Legacy will work.  After you're done with the legacy campaign, go ahead and rename the old folder sound to restore it.

3)  The actual campaign MISSIONS need to go in your maps directory.  The prologue comes in a folder called "Legacy".  It is advised you store all of the ConFed maps in that legacy folder.  C:\program files\starcraft\maps\legacy\

4)  Now, go to single player in broodwar, select "Play Custom", go to the legacy folder, and find a mission called "LegacyPrologue.scx."

5)  That's it, hold onto your seat.

6)  ***Note:  If you don't download all of the maps at once, and you "win" the maps you do have, eventually you'll see a message after you win that says "Unable to find specified campaign file."  At that point you'll need to go download the next episode and manually select it on the custom screen.  (If you download all at once, the maps will automatically carry you to the next one, so you won't need to do anything after starting the Prologue)


REMINDERS:

1)  Don't use CHEATS.  The ConFed maps are VERY trigger intensive.  If you use cheats, some of the triggers may not fire correctly.  Just take it as a word to the wise, do not use any single player cheat codes.  If you do, NexusCore Ltd. will not be held responsible if the maps do not perform correctly.

2)  SAVE OFTEN.  These are expert level maps, and you could 'lose' at any time if you're not careful.  Save often so that if you DO lose, you don't have to start all the way from the map's beginning.

3)  Avoid using the ESC key if possible.  Many triggers in this campaign are long strings and if you use ESC to end a trigger, you may miss an important event in one of the missions.

4)  You NEED BroodWar installed on your computer to play the ConFed campaign.  It is also recommended that you have a computer with at least 32 MB Ram and 150 Mhz, due to the unit intensive nature of several of the maps.


CREDITS:  (Starring: In order of appearance)

UPL Defense Net- E.S. Clarke
Dmitri Petrov- Harold "Topper" Loughry
Fleet Admiral Hayes- The "Taz" Man
Lieutenant Rand- E.S. Clarke
Doctor Halsey - Cindy "The SinFulSoul"
Commander Noble- "Furinax"
Judicator Astarte- E.S. Clarke
Judicator Drealan- Seth Hendrickson
Mallock- Cody Robinson
Vaeregoth- E.S. Clarke


(Co-Starring:  In Order of appearance)

"The Father"- Mark Yohalem
"Private" (Chapter 1) - E.S. Clarke
"Platoon Commander" (Chapter 1) - President Nuke'O'Rama
"Engineer Davis" - "Furinax"
"Vertigo CoPilot Hobbes" - E.S. Clarke
"Computer Voice (Chapter 1)" - Mark Yohalem
"Computer Voice (Chapter 2)" - WoLF`LadyDie
"Ambassador Elandrea" - Cindy "The SinFulSoul"
"Judicator Aldaris" - Original Blizzard Voice Actor
"Commander Caede" - Harold "Topper" Loughry
"Doctor Damian Saxton" - "LoveLace"
"Judicator Rak'Hal" - WoLF`LadyDie
"The Oracle" - E.S. Clarke
"Marine Leader (Chapter 8)" - Matt Clark
"Cerebrate" - E.S. Clarke


(Extras:  In Order of appearance)

"Private" (Chapter 1) - Albert Metz
"Brooke Madison Entry" (Chapter 1) - Wendy Metz
"Braxis Scientific Entry" (Chapter 1) - E.S. Clarke
"Engineer Haque" (Chapter 2) - Rashid Haque
"Welding Engineers (Male)" (Chatper 2) - E.S. Clarke
"Security 1" (Chapter 2) - "Admiral Rock"
"Security 2" (Chapter 2) - "Lord of Pain"
"Computer Voice" (Chapter 2) - "Birds"
"Yelling Soldier" (Chapter 4) - "+Keeper+ToY"
"Geneva ComChatter A" (Chapter 5) - Harold "Topper" Loughry
"Radek Yelling" (Chapter 5) - E.S. Clarke
"Griping Soldier" (Chapter 5) - "{X}~Zeratul"
"Announcing Soldier" (Chapter 5) - "+Keeper+ToY"
"News Report A" (Chapter 6) - "LoveLace"
"News Report B" (Chapter 6) - Seth Hendrickson
"News Report C" (Chapter 6) - Cindy "The SinFulSoul"
"News Report D" (Chapter 6) - E.S. Clarke
"Sergeant Taz" (Chapter 6) - "President Nuke`O`Rama"
"Judicator Albrun" (Chapter 7) - E.S. Clarke
"Judicator Methos" (Chapter 7) - "Kull"
"Dark Templar" (Chapter 7) - E.S. Clarke
"SNN Announcement" (Epilogue) - E.S. Clarke
"Deckard Cain" (Epilogue) - Joel Steudler
"Fleet Admiral Melissa Wainwright" (Epilogue) - Denise Robinson

(Musical Scores: In order...all rights reserved to their respective owners)

(Prologue) "Human Battle Suite" WarCraft II: Tides of Darkness- Blizzard Entertainment
(Chapter 3) "Nothing Else Matters" - by Metallica
(Chapter 5) "Afer Ventus" - by Enya (Shepherd Moons Album)
(Chapter 7) "Battle Scene" - by James Horner (Braveheart)
(Chapter 8) "Three suites from the movie SCREAM" - by Marco Beltrami
(Chapter 8) "Suite from the movie "Terminator" - by Brad Fiedel
(Epilogue) "Intro to movie "Starship Troopers" - by Basil Poledouris
(Epilogue) "Conclusory Music to the Movie "Braveheart" - by James Horner


Map design, story, trigger layout, characterization, dialogue, direction, and gaffing by NexusCore Ltd.


For any questions, comments, concerns, or to report a trigger glitch, please e-mail the NexusCore design team at mspawn@mailexcite.com.  

We hope you enjoy this episode of the Confederation series.




