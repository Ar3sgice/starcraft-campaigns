--------------README FILE OF THE FLAME KNIVES CAMPAIGN FOR STARCRAFT/BROODWAR--------------------

The Flame Knives is a campaign that relies on original gameplay, character development and ambience to create the proper scene for the  mysterious and ancient Protoss world of Kharnikha. 

The campaign consists on a total of 17 maps, divided in 14 parts. The storyline starts simple and straightforward, but later on many twists happen as the story takes an enigmatic and. The campaign's storyline is self-contained, so you won't have to read anything prior or after playing it. Everything you need is in the maps.

The difficulty somewhat increases during the campaign and varies from map to map, or even section to section. Overall, the later maps are more challenging than the initial ones, as should be on any campaign or game. 

-------------------------------------------------------------------------------------------------

Installing:

First, ensure that you have no "portrait" or "sound" folder in the SC dir. If so, rename any of these 2 folders or Flame Knives' unit responses and portraits will not work properly. Unzip the executable file on any folder of your preference - under the SC directory - and then extract the maps on a folder under the SC "maps" folder. It's advised that you make a new folder(i.e FlameKnives) under maps so that you can easily find the maps. After that, load the exe(FK110.exe) and select the folder where you unzipped the maps under Single Player -> Play Custom. Use the "USE MAP SETTINGS" choice.

FK is meant to be played as a campaign. Most melee maps won't work properly with it, so I don't advise trying to play melee games using the exe.

-------------------------------------------------------------------------------------------------

Feedback:

Send feedback to www.samods.org (forums), ICQ 31797721 or metathrom@hotmail.com(MSN, e-mail). Also feel free to ask for tips and such, I'll gladly help :)


Additional Info:

Keep multiple save files. It's also advised that you save after each "Objectives" update. Many maps are long and require much time and effort to be finished, so you may want to save often. 

Also, attention to details. Doodads, unit and building positioning, everything may hold some meaning, especially in some maps based on puzzle-solving. So, take your time. Many times your tasks will be made easier by simply reading dialogues, instead of just paying attention at the "Objectives" tutorials. This is where your attention span comes into play :)

Flame Knives is based on thick balance between gameplay(terrain+challenges) and storytelling(music, interactive environment). So don't expect simple gameplay such as pressing A and watching your heroes waste every enemies or easy challenges such as walk from a part of the map to another, because it's a WAR game we're talking about, not a walk in the park, right? Most maps require intelligence, strategy and countermeasure systems. If you're accustomed to easy games, cheating etc you probably won't enjoy it, and I don't encourage you to play FK if you don't enjoy challenges. Basically, if you're a newbie, wait until you've improved to try FK.

The maps were THOROUGLY TESTED AND BALANCED, and they're all completable. 

Personally, maps 6, 7, 11B, 12B and 14B are my favorites, and map 3 is my least favorite. I have no clue as to why, I think it's because the plot doesn't develop much there, in contrast to maps 1 and 2. Also, IMO, the quality level increases significantly after map 4 and keeps improving until the end of the campaign.


Credits:

Metathrom(me): Staredit work, testing, sound editing, doodad work
Star Alliance: hosting
Robddav, Snoopy: Tech help
Thrill, Taeradun: Doodad work
Joel Steudler: Title screen
Taeradun: Splash screen
Ling-Mac, Blade66777, Freak, PlasmaWrath, RsRioter: beta testers
...and all fans, of course :D


I hope you enjoy Flame Knives. I sure enjoyed making it :)
                                                                                                                                        SA-Metathrom

-------------------------------------------------------------------------------------------------

Disclaimer:

Flame Knives� is owned by Thiago Andrade Santos. Do not distribute any Flame Knives maps, edited or not, or upload them to any sites. Do not extract sound effects from Flame Knives maps before asking me for permission. E-mail: metathrom@hotmail.com
ICQ: Metathrom, 31797721
Star Alliance Forum Account: Metathrom
IRC Nickname: SA-Meta on beyondirc.net