Bootcamp

This campaign, and all music contained therein, is copyrighted
�2006-2007 Tamas McCoy, and is a joint venture of Samods and
Campaign Creations. All rights reserved.

This map may not be modified, in whole or in part, without express
written permission from Tamas McCoy.

Tamas "Gemini" McCoy
tamasmccoy@gmail.com
------------------------------------------------------------------
TO PLAY BOOTCAMP:

You must have Starcraft and Brood War installed on your computer.

1. Extract the .zip file in your Starcraft/maps folder. If you
   prefer, you may extract it in a subfolder of /maps.

2. Start Starcraft using SCMLoader. If you do not currently have
   this program, you can find it here:

http://shadowflare.samods.org/dwnload.html#Downloading%20and%20Installing%20Programs

3. Select Single Player, and choose Expansion.

4. Select Play Custom.

5. Load up (1)Bootcamp Ch-1.scx, choosing "Use Map Settings," and enjoy!