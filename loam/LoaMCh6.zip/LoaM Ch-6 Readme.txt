A few tips on playing Chapter 6:

Due to the fact that real-life seconds and Starcraft seconds can and
often do differ, and thus mess up the timing that is set up in the automated
sequences, please do not modify the speed settings. Just let it run at
normal speed.

The boss is considerably hard. I recommend you save before you face him. On
that note, the map itself is considerably harder than past LoaM maps, so it
is recommended to save often.

Credit goes to Kei00000 for most of the terrain design.

All the chapters of Life of a Marine can be found at:
http://staff.samods.org/Gemini/
----------------------------------------------------------------------------
Life of a Marine
Chapter 6: Shadow's Grave

This map is copyrighted � 1999-2004 Gemini Productions. All rights reserved.

This map may not be modified, in whole or in part, without express written
permission from Tamas McCoy.

Tamas "Gemini" McCoy
tamasmccoy@lycos.com