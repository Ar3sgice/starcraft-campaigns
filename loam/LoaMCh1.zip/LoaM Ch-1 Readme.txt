A few tips on playing Chapter 1:

The opening intro has great dialogue and is a really good way of setting the
story and mood of the game. However, having to sit through it several times
because of losing the actual mission is not fun, as the intro takes around
10-15 minutes to complete. It is strongly recommended that you SAVE as soon
as the introduction is over.

Also, due to the fact that real-life seconds and Starcraft seconds can and
often do differ, and thus mess up the timing that is set up in the automated
sequences, please do not modify the speed settings. Just let it run at
normal speed.

All the chapters of Life of a Marine can be found at:
http://staff.samods.org/Gemini/
----------------------------------------------------------------------------
Life of a Marine
Chapter 1: Trials

This map is copyrighted � 1999-2004 Gemini Productions. All rights reserved.

This map may not be modified, in whole or in part, without express written
permission from Tamas McCoy.

Tamas "Gemini" McCoy
tamasmccoy@lycos.com