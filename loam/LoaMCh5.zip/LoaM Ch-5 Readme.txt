A few tips on playing Chapter 5:

Due to the fact that real-life seconds and Starcraft seconds can and
often do differ, and thus mess up the timing that is set up in the automated
sequences, please do not modify the speed settings. Just let it run at
normal speed.

After using the AirTaxi to get from station to station, make sure to clear
your units off any AirTaxi beacon. The AirTaxi won't pick you up again until you do.

All the chapters of Life of a Marine can be found at:
http://staff.samods.org/Gemini/
----------------------------------------------------------------------------
Life of a Marine
Chapter 5: Twenty-Two Point Three

This map is copyrighted � 1999-2004 Gemini Productions. All rights reserved.

This map may not be modified, in whole or in part, without express written
permission from Tamas McCoy.

Tamas "Gemini" McCoy
tamasmccoy@lycos.com