----------------------
The Antioch Chronicles
Episode I: Psionic Storm (v1.04SE)

� 1998, 1999 Auspex Turmalis (Ruben Moreno)
http://antioch.tech-base.com

All Antioch Chronicles campaign sounds, characters, story concepts and related media are a
� Copyright of Auspex Turmalis (Ruben Moreno) and may not be used without express written
permission. The Antioch Chronicles is a freeware StarCraft campaign and as such may be
distributed without cost as long as all related files are bundled together, unmodified,
and as long as no profit is made from said distribution.

If you have received an incomplete version of this campaign (i.e., you are missing the
unit sound and portrait pack, one or more of the eight missions, and/or the epilogue),
please contact auspex@tech-base.com. The latest full version of the campaign can be
found at http://antioch.tech-base.com.

Suggestions for future episodes are welcome.

For Aiur.
--Auspex Turmalis (CWAL)
http://antioch.tech-base.com/


-- Credits --
-------------

Story and Script
  Auspex Turmalis (Ruben Moreno)
Map and Trigger Design
  Auspex Turmalis
Voices and Sound Design
  Auspex Turmalis


-- Setup Information --
-----------------------

(WARNING! The Special Edition (v1.04SE) of Psionic Storm will only work with StarCraft or
Brood War versions 1.04 or later. It will not work with StarCraft versions 1.00 through
1.03. To get version 1.04, you either need to download the patch from www.blizzard.com or
through Battle.net, or purchase the Brood War expansion set.)

Since Antioch contains new hero sounds and portraits, it's important to follow a few simple
setup instructions in order to get everything running perfectly. The first thing to do is
to create a new folder under your existing StarCraft maps folder (for example, antioch)
and then unzip the campaign to that folder. This will extract the SCMs, a readme file, a
portrait folder, and a sound folder containing all the new unit sounds. To enable the new
sounds, move the sound folder into your main StarCraft folder. 

The new unit sounds will only work when the sound folder is kept in the main StarCraft
directory, when the name is kept exactly as it is, and when the file and directory
structure within the sound folder itself is kept intact. To disable the sounds when not
playing the campaign, either rename the folder (giving it a temporary name like
antiochsound or stuff or temp) or move it to a different location. It's often easy to
forget to disable the sounds; if you're playing a regular game of SC and your units
take on different personalities, this sound folder is probably the culprit. ;-) The same
process is used with the portrait folder to enable the new altered portraits for Turmalis,
Khorun, Nurohk and Charlie Mox.

Once the new game files are in place, simply go into StarCraft and start a Custom game
like you would when playing any other SCM. Under the new folder you've created, select
(1)Antioch 1-01.scm with Use Map Settings as the game type and you're on your way. That's
about it. Enjoy!


-- The Story --
---------------

"You speak of knowledge, Judicator. You speak of experience. I have journeyed through the
darkness between the most distant stars. I have beheld the births of negative suns, and
born witness to the entropy of entire realities. Unto my experience, Aldaris, all that
you have built here on Aiur is but a fleeting dream, a dream from which your precious
Conclave shall awaken, finding themselves drowned in a greater nightmare."
-- Zeratul, Praetor of the Dark Templar


Prophecy Unveiled

The ashes have cleared. The air is still. Over the face of Aiur hangs a tenebrous mood,
as a former paradise struggles to regain a foothold on the cusp of survival. The Overmind
is no more, but the Homeworld lies tattered, broken, humbled. Cities stand as mere
remnants of the glory they once proclaimed. Judicator, Templar and Khalai alike struggle
to rebuild their homes and centers of power. The Conclave has learned its lesson, but
the nightmare is far from over.

Out in the morning mist, the Zealots can already be seen standing in a blue glow, holding
a silent vigil amid floating pylons and ornate structures. Through the haze, a pair of
nameless figures stands like granite before the silhouette of an ancient, commanding
temple; one erect, still and undaunted--the other, a four-limbed construct waiting
patiently for the storm. Both bear the dark markings of the Sargas tribe. Both have seen
countless battles. Both are aware of a presence that may threaten all that they know and
cherish. The heart of Aiur still beats with an unmistakable vitality, but a dark,
approaching thunderhead cackles derisively on the horizon with a purity of essence so
vile it can only belong to one force--the Zerg. The tempest is upon them. The stage has
been set.


The First Stroke

Our story begins at the outskirts of the province of Antioch. A shadow falls on a nearby
temple--a dim, stifling presence, full of primitive drive. The link falters. Shields
flicker. A living tidal wave emerges from the nearby hill bank. Claws and teeth swarm
into the secluded valley. The temple guards slash into the onslaught. Warriors fall.
Pylons are crushed. The luckier Zealots make it to high ground. In the minds of all
Protoss defending the temple, suddenly--silence.

There is no escape.


-- The Cast --
--------------

Turmalis

Protoss, age 692
Judicator
Advisor to the Antioch Relief Expedition

With a long record of distinguished service under the Assembly, Turmalis was one of the
Judicatura who had crewed the Arbiters in defense of the Conclave's heart during the time
of Tassadar's incarceration, prior to the destruction of the Overmind. Though he had no
particular love for the late Tassadar, Turmalis appreciates the results of his efforts
and therefore tries to keep an open--if detached--mind, especially when it comes to
matters of the Dark Templar or bothersome Terrans. Though deadened to surprises of battle
long since turned mundane, Turmalis nevertheless sees the importance of maintaining a
vigilant front against the advances of still-lurking Zerg.


Khorun

Protoss, age 331
Templar
Warrior of the Khala

A descendant of the Sargas tribe, Khorun was one of the strongest and most fearsome
warriors in the province of Antioch, until his twin, Nurohk, fell in battle, only to be
reborn as a Dragoon. Until the time of Nurohk's return, Khorun secluded himself in the
provincial temple, strengthening his body and mind for the battle against the Zerg that
already loomed on the horizon. While his brethren still respect him, especially after his
fierce redemption in the liberation of Aiur, Khorun feels that he must somehow prove
himself again, both to his twin and to his fellow warriors. To this end, his feats in
battle have only been matched by his thirst for Zerg carnage.


Nurohk

Protoss, age 331
Templar
Warrior of the Khala

Nurohk, like Khorun, had long been considered one of Antioch's most daring warriors. The
day that Nurohk fell to a pack of Ultralisks was at once gruesome and glorious. With the
former Zealot's body now housed within the shell of a Dragoon, Nurohk graciously allows
his twin to fight for the greater glory, while supporting his forces wherever and whenever
possible. Though Nurohk has accepted his fate like many a fallen warrior before him, those
who serve with him know better than to bring up the subject. For Nurohk, the past should
remain in the past.


Nannoth/Taeradun

Protoss, age Unknown
Former High Templars
Guardian of the Temple of Jepok

Nannoth and Taeradun were once highly regarded members of the High Templar who led the
forces beneath them to victory countless times in ages past. When called upon to make the
ultimate sacrifice in the throes of battle, the two forged a new beginning as a single
entity of incredible power. After the mighty Archon's strange disappearance, the rumor
spread that he had simply fallen in battle defending his brethren. If he were to return
today, the realization would most likely take any Protoss warrior by surprise.


Charlie Mox

Male Terran, age 32
Former Morian Mining Captain
Commander of Kel-Morian Special Ops Detachment

Charlie Mox abandoned his commission as captain shortly before the Morian Mining
Coalition's merger with the Kelanis Guild. Dissatisfied with the pirate organization's
monopolizing practices, and unwilling to turn to the Confederacy, Mox bided his time in
the hopes of finding a better venue for his services. When Mengsk's Dominion seized power,
Mox grudgingly rejoined the Combine, after a trusted source recounted the horror of the
former Lt. Kerrigan's fate. Better to work for pirates than to become an unwitting puppet
of Arcturus or a minion of the Zerg.


Dale Gurney

Male Terran, age 26
Former Morian Transport Gunner
Squad Officer in Kel-Morian Special Ops Detachment

Dale Gurney was one of the first to join Mox when he left the Coalition. Already a
veteran walker pilot and gunner, Gurney set out to recruit the most experienced soldiers
with the intention of forming a roving infantry and mechanized support squad--comprised
entirely of mercenaries. Gurney intended to leave Mox after he had enough money to set up
his own base, but when the Confederacy fell, the only profit to be made seemed to be in
the heart of the Kel-Morian Combine. Because of their history together, Mox and Gurney
were assigned to the same division.

----------------------