----------------------
The Antioch Chronicles
Episode II: Negative Suns (v1.01)

� 1999 Auspex Studios
http://antioch.tech-base.com
http://www.auspexstudios.com

All Antioch Chronicles campaign sounds, characters, story concepts and related media are a
� Copyright of Auspex Studios and may not be used without express written permission. The
Antioch Chronicles is a freeware StarCraft campaign and as such may be distributed without
cost as long as all related files are bundled together, unmodified, and as long as no
profit is made from said distribution.

If you have received an incomplete version of this campaign (i.e., you are missing the
unit sound and portrait packs, one or more of the eight missions, the prologue and/or
epilogue), please contact auspex@tech-base.com. The latest full version of the campaign
can be found at:
http://antioch.tech-base.com/

Suggestions for future episodes are welcome.

For Aiur.
--Auspex Turmalis (CWAL)
http://antioch.tech-base.com/
http://www.auspexstudios.com/


-- SETUP INFORMATION --
-----------------------

(WARNING! Episode II - Negative Suns will only work with the Brood War expansion set.)

STEP 1:  Download and/or move all the ZIP files into your StarCraft "maps" folder. In
addition to the "readme.txt" file included in each ZIP, the contents of each file are
listed below. Files marked with a double asterisk (**) have been updated since v1.00,
and are the only files needed for players upgrading from v1.00 to v1.01.

A2v101-0.zip -- "sound/protoss" and "portrait"
A2v101-1.zip -- "sound/terran"
A2v101-2.zip ** "(1)Antioch 2-00.scx"
A2v101-3.zip ** "(1)Antioch 2-01.scx"
A2v101-4.zip ** "(1)Antioch 2-02.scx"
A2v101-5.zip -- "(1)Antioch 2-03.scx"
                "(1)Antioch 2-04.scx"
A2v101-6.zip ** "(1)Antioch 2-05.scx"
A2v101-7.zip ** "(1)Antioch 2-06.scx"
A2v101-8.zip ** "(1)Antioch 2-07.scx"
A2v101-9.zip ** "(1)Antioch 2-08.scx"
                "(1)Antioch 2-09.scx"

STEP 2:  Unzip the files where they are. They should create a new "antioch2" folder, and
extract all the files into that folder, including a "sound" subfolder and a "portrait"
subfolder. Make sure you are using WinZip or PKZip and that it is set up to extract files
with full path names and/or subfolder info (this should be the default -- if you
end up with a bunch of files all in your "maps" folder, and no "antioch2," "sound," or
"portrait" folders, then something is wrong). When prompted to overwrite any existing
"antioch2" or "sound" folders (in your "maps" folder, that is), go ahead. This is important
for the two sound file ZIPs (which both contain the "antioch2/sound" path), as well as for
players upgrading to v1.01 from v1.00.

STEP 3:  Check your main StarCraft folder for any "sound" or "portrait" folders from other
campaigns or customs. Move these to a safe location, or the new Antioch sounds and portraits
may overwrite your old customs.

STEP 4:  Move the "sound" folder from "antioch2" into your main StarCraft directory. To
make sure you hear the proper sounds, check to see that the following folder structure is
intact, and that each folder contains the proper .WAV files that correspond to its folder
name (pabpss00.wav and so forth for "arbiter," as an example):

Starcraft
  sound
    protoss
      arbiter
      Artanis
      fenixd
      fenixz
      tassadar
      zeratul
    terran
      duket
      Duran
      firebat
      goliath
      raynorm
      raynorv

(Note: The hero unit response sounds for Episode II are all-new, including the heroes
returning from Episode I, re-recorded in the spirit of the originals but at a much higher
level of quality. If you would like to preserve your existing Antioch Episode I sounds,
move them to a safe location before proceeding with the installation of the Episode II
sounds. As always, to disable the Episode II sounds, rename the "sound" folder or move
it to another folder.)

STEP 5:  Move the "portrait" folder from "antioch2" into your main StarCraft directory. To
make sure you see the proper portraits, check to see that the following folder structure is
intact, and that each folder contains .SMK files that correspond to its folder name:

Starcraft
  portrait
    PAdvisor
    PArbiter
    PArtanis
    tfirebat
    TSam
    UDuke
    UFenDrag
    UFenZeal
    UJim
    Umengsk
    UTassadar
    UZeratul

(Note: To disable the Episode II portraits, rename the "portrait" folder or move it to
another folder.)

STEP 6:  Start StarCraft and select Single Player, then Custom Game, and go to the
"antioch2" folder. Be sure to set the game type to "Use Map Settings," and then choose
"(1)Antioch 2-00.scx" to begin.

(NOTE:  You may, of course, move the "antioch2" folder into the "campaigns" folder under
"maps," if you so desire.)

Enjoy!


-- AUSPEX STUDIOS --
--------------------

Ruben "Auspex Turmalis" Moreno:  Chief Mastermind
Eric "Zeus Legion" Dieter:  Senior Henchman
Juan "Ytse-Jam" Mantilla:  Lead Wrestler
Eric "Macbeth" Ladd:  Whiskey Shreve
Brian "HoodZ" Cosmiano:  Cosmic Art Master


-- TEAM ANTIOCH II --
---------------------

Concept, Script, Dialogue:  Ruben Moreno
Plot/Additional Dialogue:  Eric Dieter
Additional Dialogue/Abstract Drunken Ideas:  Everyone

Maps, Triggers, Mission Design:  Ruben Moreno
Hero Portrait Alterations:  Ruben Moreno
Sound Editor:  Ruben "Is This Thing On?" Moreno
Antioch Web Lord:  Ruben "Jack of All Trades" Moreno
Web Site Character Art:  Brian Cosmiano
Lead Gaffer:  Gary "Whatchu Talkin 'Bout?" Coleman
Public Relations:  Denise Richards

(Okay, so maybe not those last two... ;-)

Portions of the map for Mission 7, "Mirror, Mirror," based on Blizzard Entertainment's
Brood War Protoss 7, "The Insurgent."

No Civilians were harmed during the making of this campaign. (Really. For real. Honest.)


-- EPISODE II VOICE CAST --
---------------------------

Ruben "Man of a Thousand Faces" Moreno, as (in order of appearance):
  Charlie Mox, Turmalis, Dale Gurney, Nurohk, Khorun, Xenon, Quatto, Trent "Trench" Aster,
  Nannoth/Taeradun, Crowley, Khrillian, and various Marine and Civilian extras.

Eric Dieter, as:
  Moloch, Mr. HoloFone, and Bora Dalis PA Captain

Ytse-Jam, as:
  Mason Rockwell

Eric Ladd, as:
  Ian Anduin

Original StarCraft voices courtesy (and property) of Blizzard Entertainment


-- A NOTE OF THANKS --
----------------------

-- Auspex would like to thank:

Blizzard Entertainment, Gunslinger, the folks at Warzone and The Unholy Battlegrounds,
Desler, SCX, Smoke & MirrorZ (for the EARLY early feedback), m@crowar (master of the
enlarged map picture), X-ViRGE, ZealotOnAStick, Xenophanes, The Lapdragon, all the
StarCraft sites who have ever made hosting offers or simply posted Antioch news, all the
patient Antioch fans (thank you for the ridiculous amount of E-mail!), the ancient
Vanguard guys, and the old-school Operation CWAL crew -- we're all still alive! (Yes,
we're a cheat AND we're in the SC credits, for you newbies out there.)

In addition to anyone else he may have forgotten, Auspex would also like to thank the WWF
(and The Rock -- it's a tribute, man); Bill Harms at PC Gamer; Syntrillium Software;
Adrian Dunston (and the rest of the Thompson Theatre gang); Alfred, Lord Tennyson for "The
Idylls of the King"; George Lucas for all the influences; the guys behind Thumb Wars
(ROFLMFAO!); Star Trek - Deep Space Nine (goodbye... *sniff*); Chunky Chips Ahoy; Billy
Sheehan (thanks for the "troubleshooting" advice and that insane Ampeg preamp); Rush,
Dream Theater and all prog musicians everywhere; and of course, my family, who has been
putting up with this (and me) for so long. Cheers!

P.S. Thanks for having faith!


-- Zeus would like to thank:

Team Antioch II (a.k.a. Auspex Studios) for being the most professional, creative and fun
guys to work with.

PC Gamer and PC Accelerator (I'm still waiting for the all-Gia pictorial issue...) for
bringing me the best information on games and lighting up my days at the usually dreaded
mailbox.

The fans who downloaded this 80mb+ monster and the Starcraft community who stood by us for
the long haul. I hope you all have as much fun playing it as we had making it.

Blizzard Entertainment, the people who made it all possible.

Zeus would like to dedicate his work on this campaign to his childhood idols:

Bruce Lee
Optimus Prime

In Memory of Jim "T.M. Maple" Burke


-- Ytse-Jam would like to thank:

The source of my inspiration, Lucy, the love of my life.

Dream Theater, especially John Petrucci and Mike Portnoy. Thanks for being the leaders of
a new era of progressive rock. John, I hope to one day be half the guitar player you are.

The WWF for all the laughs and entertainment throughout the years. I was there from the
Hogan era, up to the Stone Cold era. How things have changed.

This performance is dedicated in the memory of Owen Hart. May you rest in peace.


-- Macbeth would like to thank:

"The Bard" for his literary contributions, Auspex for this opportunity, and Blizzard for
making great ways to pass the time.


-- EPISODE II PREFACE --
------------------------

"En Taro Adun, Executor. Though we all grieve for the loss of mighty Tassadar, we must
find the resolve to carry on. He sacrificed himself to destroy the Overmind, but many
Zerg still rage across our ruined homeworld. Without the Conclave to lead us, or the
protection of our great fleets, it seems we must fend for ourselves."
-- Aldaris, Advisor to the Koprulu Expeditionary Force


A Dying World Abandoned

Zealots and Dragoons tear through the dark canyon. Monstrous waves of Zerg fly overhead,
patrolling the ruins of a dozen cities. It is an eerie atmosphere. The warp gate is
located. The refugees mass in one throng and pour through the portal, all of one mind to
abandon their once majestic home. It is their only choice. A brave Terran and a stalwart
Dragoon stay behind to safeguard the rift. The air crackles with energy. The deed is done.
All are safe. All have been evacuated. All have been accounted for.

All, that is, save for a small group of Templar standing in silent vigil, looking up out
of a deep valley, the glow of floating pylons in the night illuminating the slanting stone
faces of a temple as ancient as time itself... the Temple of Jepok. A form emerges from
the shadows, ink-blue and shimmering. A being of light glides toward it. The Zealots
on guard turn, hearing the acrid utterances stab into the night like black, sharpened
blades. The shadow stalks off. The Archon turns, lost in thought. All is not well.

High in orbit, a band of battle-hardened Terrans toil in the construction of a new harbor,
a bastion of steel overlooking a dying world. They have visitors. A small Protoss escort
flies in, cloaked beside a vessel radiating powerful psionic energy. The ship is an
Arbiter, and the being responsible for its action is a Judicator with much on his mind.


The Second Stroke

Solitary in his hunt, the dark figure moves silently, called to the west of the valley.
This presence he has felt grows vaguely stronger. It is only a matter of time. It cannot
hide. It cannot leave. It has made itself conspicuous to him--to a being of shadow already
attuned to dark energies. It is only a matter of time. He has almost discovered the truth.

It is only a matter of time.


(Timeline: Episode II of The Antioch Chronicles takes place during the Brood War Protoss
Campaign, "The Stand.")


-- ROSTER OF HEROES --
----------------------

Turmalis

Protoss, age 692
Judicator
Advisor to the Antioch Relief Expedition

With a long record of distinguished service under the Assembly, Turmalis was one of the
Judicatura who had crewed the Arbiters in defense of the Conclave's heart during the time
of Tassadar's incarceration, prior to the destruction of the Overmind. Though he had no
particular love for the late Tassadar, Turmalis appreciates the results of his efforts
and therefore tries to keep an open--if detached--mind, especially when it comes to
matters of the Dark Templar or bothersome Terrans. Though deadened to surprises of battle
long since turned mundane, Turmalis nevertheless sees the importance of maintaining a
vigilant front against the advances of still-lurking Zerg.

"Detachment breeds competence."


Khorun

Protoss, age 331
Templar
Warrior of the Khala

A descendant of the Sargas tribe, Khorun was one of the strongest and most fearsome
warriors in the province of Antioch, until his twin, Nurohk, fell in battle, only to be
reborn as a Dragoon. Until the time of Nurohk's return, Khorun secluded himself in the
provincial temple, strengthening his body and mind for the battle against the Zerg that
already loomed on the horizon. While his brethren still respect him, especially after his
fierce redemption in the liberation of Aiur, Khorun feels that he must somehow prove
himself again, both to his twin and to his fellow warriors. To this end, his feats in
battle have only been matched by his thirst for Zerg carnage.

"When war is done, and all is ashes, we will be remembered for how we died in the dark,
not how we lived in the light."


Nurohk

Protoss, age 331
Templar
Warrior of the Khala

Nurohk, like Khorun, had long been considered one of Antioch's most daring warriors. The
day that Nurohk fell to a pack of Ultralisks was at once gruesome and glorious. With the
former Zealot's body now housed within the shell of a Dragoon, Nurohk graciously allows
his twin to fight for the greater glory, while supporting his forces wherever and whenever
possible. Though Nurohk has accepted his fate like many a fallen warrior before him, those
who serve with him know better than to bring up the subject. For Nurohk, the past should
remain in the past.

"Destroy this shell and I merely will find another one, in our strongest steel or your
darkest dreams."


Nannoth/Taeradun

Protoss, age Unknown
Former High Templars
Guardian of the Temple of Jepok

Nannoth and Taeradun were once highly regarded members of the High Templar who led the
forces beneath them to victory countless times in ages past. When called upon to make the
ultimate sacrifice in the throes of battle, the two forged a new beginning as a single
entity of incredible power. After the mighty Archon's strange disappearance, the rumor
spread that he had simply fallen in battle defending his brethren. If he were to return
today, the realization would most likely take any Protoss warrior by surprise.

"Liberavi animam meam!"


Charlie Mox

Male Terran, age 32
Former Morian Mining Captain
Commander of Kel-Morian Special Ops Detachment

Charlie Mox abandoned his commission as captain shortly before the Morian Mining
Coalition's merger with the Kelanis Guild. Dissatisfied with the pirate organization's
monopolizing practices, and unwilling to turn to the Confederacy, Mox bided his time in
the hopes of finding a better venue for his services. When Mengsk's Dominion seized power,
Mox grudgingly rejoined the Combine, after a trusted source recounted the horror of the
former Lt. Kerrigan's fate. Better to work for pirates than to become an unwitting puppet
of Arcturus or a minion of the Zerg.

"Trust me to watch your back, mate, and I'll watch it. Trust me to bail you out more than
twice in one day, and you're rollin' the dice."


Dale Gurney

Male Terran, age 26
Former Morian Transport Gunner
Squad Officer in Kel-Morian Special Ops Detachment

Dale Gurney was one of the first to join Mox when he left the Coalition. Already a
veteran walker pilot and gunner, Gurney set out to recruit the most experienced soldiers
with the intention of forming a roving infantry and mechanized support squad--comprised
entirely of mercenaries. Gurney intended to leave Mox after he had enough money to set up
his own base, but when the Confederacy fell, the only profit to be made seemed to be in
the heart of the Kel-Morian Combine. Because of their history together, Mox and Gurney
were assigned to the same division.

"Somebody get me a hot dog and a beer."


Moloch

Protoss, age 487
Dark Templar
Hunter / Assassin

Moloch was one of Zeratul's ilk who arrived with him on Aiur just before the trial of
Tassadar. A former student of the Templars Nannoth and Taeradun, Moloch had meditated
long on the ancient teachings of Khas and Adun, but ultimately had been driven to sever
himself from the communal link, joining the wayward bands of Dark Templar who had long
since fled Aiur. His return to the Protoss homeworld held both the promise of redemption
and the threat of damnation. With Zeratul attending to larger matters, Moloch was ordered
to seek out a growing disturbance near the temple grounds at Antioch, where Fenix had
fallen.

"Each battle is simply a struggle for survival. There is no honor or glory to be won in
it. There is only the hollow victory of choosing who shall live and who shall die THIS
time."


Trent "Trench" Aster

Male Terran, age 29
Freelance Covert Ops Specialist
Unaffiliated

Not much is known about the man named Trent Aster, if that's even his real name. Living
in the shadows of half-abandoned fringe worlds, preying on the seedy backstreet commerce
of the darkest dregs of Terran society, Aster plies the age-old trade of misdirection
and motive, hunches and hard proof. A specialist in the retrieval of highly sensitive
classified information, Aster has been known to frequent the rougher zones of major
spaceports, known to contacts in the area as the man named "Trench," for any who might
seek to employ his considerable talents. While it was once rumored that he worked for the
Umojan Protectorate under Minister Jorgensen, most streetwise cads would probably point
anyone mentioning the name "Trench" in the direction of Korhal or the Tornod system.

"Yeah, ramble on about how tough you are, boy. Most people don't see the bullet that hits
'em in the back of the head."


Ian Anduin

Male Terran, age 56
Hermit / Scientist
Marshal of the Tornod Highlands

Ian Anduin lived in the Tornod Highlands for most of his adolescent life, where he learned
to tinker with the new technology that freighters, cargo vessels and off-world transports
often deposited in nearby outposts as either trade surplus or mission refuse. When the
Zerg overran Tornod III, Anduin helped his people fend off the rampaging creatures until a
division of Mengsk's forces retook the planet -- an act that earned him the position of
Marshal of the Highlands. Now under Dominion control, the major civilized centers on
Tornod III have evolved into a network of corrupt city-states driven by rampant bribery
and mutual economic and political back-scratching... leaving Anduin's idyllic highland
home an easy target for thieves and well-armed pirates.

"Every man dies. Not every man truly keeps down his beer."


Mason Rockwell

Male Terran, age 24
Former Morian Artillery Officer
Squad Officer on New Brisbane Station

Mason Rockwell was a highly sought-after artillery specialist who had been stationed on
the planet Moria for most of his early career. Now settling into his prime, "The General"
has decided to have a go at it in the mercenary field, offering his services (and inflated
ego) to the highest bidder. Rockwell's command style and combat tactics are distinctive,
to say the least -- many a superior officer has instantly recognized the blaring music
pumping from within his modified siege tank, even across an entire battlefield in the heat
of combat. His cocky demeanor belies a serious strength of mind and resolve that always
carries him through to the end of his assigned task. For Mason Rockwell, failure is not an
option, and personal embarrassment amounts to nothing short of sacrilege.

"YOU want to lock horns with The Great One?"


Khrillian

Protoss, age 442
Dark Templar
Adventurer / Scribe

Khrillian had always cultivated a deep understanding of the ancient Protoss texts. Steeped
in the extensive lore of Aiur's history, the warrior honed not only his body in battle,
but also his mind in the pursuit of knowledge. The sole custodian of his predecessor's
journals, Khrillian had spent many long hours studying in the archives on his former
homeworld. Also an accomplished pilot in his own right, Khrillian eventually earned the
leadership of an entire air division as a member of Zeratul's personal guard. Khrillian's
small but mobile fleet is among the deadliest on the dark world of Shakuras.

"History has been recorded for a purpose. Be mindful of what has come before, that it may
guide you toward what is to be."


----------------------
